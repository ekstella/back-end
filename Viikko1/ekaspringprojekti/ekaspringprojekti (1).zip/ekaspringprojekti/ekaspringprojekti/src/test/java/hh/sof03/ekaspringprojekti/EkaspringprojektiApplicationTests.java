package hh.sof03.ekaspringprojekti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkaspringprojektiApplicationTests {

	@Test
	void contextLoads() {
	}

}
