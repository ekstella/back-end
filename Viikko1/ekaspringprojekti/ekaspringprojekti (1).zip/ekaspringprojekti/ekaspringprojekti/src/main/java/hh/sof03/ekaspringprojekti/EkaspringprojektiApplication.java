package hh.sof03.ekaspringprojekti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkaspringprojektiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EkaspringprojektiApplication.class, args);
	}

}
