package hh.sof03.carlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
