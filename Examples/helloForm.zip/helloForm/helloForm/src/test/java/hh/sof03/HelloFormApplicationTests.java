package hh.sof03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class HelloFormApplicationTests {

	@Test
	public void contextLoads() {
	}

}
